// Service worker — orquestra o fluxo "Virar afiliado automático":
//
// 1. shopee-product.js (rodando na página do produto na Shopee) manda
//    AFFILIATE_REQUEST com o título/URL do produto.
// 2. Este arquivo abre uma aba escondida no Portal de Afiliados da Shopee,
//    guarda o pedido em chrome.storage.local (o service worker pode ser
//    encerrado a qualquer momento, então nada fica só em memória) e passa o
//    requestId pra aba nova via hash da URL.
// 3. shopee-affiliate.js (rodando na aba do portal) busca o produto, clica
//    em "Obter link", lê o link gerado e manda de volta AFFILIATE_RESULT.
// 4. Este arquivo fecha a aba escondida, avisa a aba original da Shopee
//    (pra atualizar o botão) e entrega o link pra qualquer aba do Fornecefy
//    aberta — ou guarda numa fila se nenhuma estiver aberta ainda.

const AFFILIATE_TOOL_URL = "https://affiliate.shopee.com.br/offer/product_offer";
const PENDING_PREFIX = "pending_";
const QUEUE_KEY = "unsynced_links";

// Qualquer origem onde o Shopfy pode estar rodando — produção (domínio
// próprio e o alias da Vercel) e o ambiente local de dev. Usado tanto pra
// entregar o link recém-gerado quanto pra achar a aba certa no popup.
const APP_URL_PATTERNS = [
  "https://shoppfy.online/*",
  "https://www.shoppfy.online/*",
  "https://shoppfy-five.vercel.app/*",
  "http://localhost/*",
  "http://127.0.0.1/*",
];

function genId() {
  return (
    "req_" +
    Date.now().toString(36) +
    "_" +
    Math.random().toString(36).slice(2, 10)
  );
}

async function getPending(requestId) {
  const data = await chrome.storage.local.get(PENDING_PREFIX + requestId);
  return data[PENDING_PREFIX + requestId];
}

async function setPending(requestId, value) {
  await chrome.storage.local.set({ [PENDING_PREFIX + requestId]: value });
}

async function clearPending(requestId) {
  await chrome.storage.local.remove(PENDING_PREFIX + requestId);
}

async function queueUnsynced(payload) {
  const data = await chrome.storage.local.get(QUEUE_KEY);
  const queue = data[QUEUE_KEY] || [];
  queue.push(payload);
  await chrome.storage.local.set({ [QUEUE_KEY]: queue });
}

async function flushQueueToTab(tabId) {
  const data = await chrome.storage.local.get(QUEUE_KEY);
  const queue = data[QUEUE_KEY] || [];
  if (queue.length === 0) return;
  for (const payload of queue) {
    try {
      await chrome.tabs.sendMessage(tabId, { type: "SAVE_LINK", payload });
    } catch {
      // aba pode ter fechado no meio do caminho — mantém na fila
      return;
    }
  }
  await chrome.storage.local.set({ [QUEUE_KEY]: [] });
}

async function notify(title, message) {
  try {
    await chrome.notifications.create({
      type: "basic",
      iconUrl: "icons/icon128.png",
      title,
      message,
    });
  } catch {
    // notifications é opcional — se falhar (ex: permissão negada), ignora
  }
}

chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
  if (!message || typeof message !== "object") return;

  if (message.type === "AFFILIATE_REQUEST") {
    (async () => {
      const requestId = genId();
      const originTabId = sender.tab ? sender.tab.id : null;
      const originWindowId = sender.tab ? sender.tab.windowId : null;

      // Com o itemId (vem direto da URL do produto, sem esperar nada), dá
      // pra ir direto na página de oferta desse produto específico no portal
      // — sem precisar buscar por nome. É bem mais rápido e confiável do que
      // buscar por texto (que dependia do título da página já ter carregado
      // o nome real, o que podia demorar dezenas de segundos).
      const url = message.itemId
        ? `https://affiliate.shopee.com.br/offer/product_offer/${message.itemId}#fornecefy_req=${requestId}`
        : `${AFFILIATE_TOOL_URL}#fornecefy_req=${requestId}`;

      // Precisa ser active:true. Abas em segundo plano (active:false) sofrem
      // "throttling" agressivo de timers no Chrome (setTimeout roda bem mais
      // devagar), e a automação nessa aba depende de setTimeout pra
      // pesquisar/esperar elementos — com a aba escondida ela sempre estourava
      // o tempo limite e falhava. Como consequência a aba abre em primeiro
      // plano por alguns segundos e volta sozinha pra aba original no final.
      const tab = await chrome.tabs.create({ url, active: true });

      await setPending(requestId, {
        title: message.title,
        productUrl: message.productUrl,
        image: message.image,
        itemId: message.itemId,
        originTabId,
        originWindowId,
        toolTabId: tab.id,
        status: "searching",
        createdAt: Date.now(),
      });

      sendResponse({ requestId });
    })();
    return true; // resposta assíncrona
  }

  if (message.type === "AFFILIATE_RESULT") {
    (async () => {
      const pending = await getPending(message.requestId);
      if (!pending) return;

      if (pending.toolTabId) {
        chrome.tabs.remove(pending.toolTabId).catch(() => {});
      }

      // Constrói o payload ANTES de avisar a aba de origem, pra poder incluir
      // um resumo dele na mensagem AFFILIATE_DONE — isso dá visibilidade de
      // debug (via host.dataset.fornecefyLast) sobre o que realmente foi
      // extraído/enviado pro Fornecefy, sem precisar inspecionar a aba do
      // portal (que já fecha sozinha logo em seguida).
      let payload = null;
      if (message.ok) {
        // O nome/imagem extraídos direto da página de oferta do portal (que
        // carrega rápido, sem depender da SPA da Shopee hidratar) são mais
        // confiáveis que os da página de origem — usa eles quando vierem.
        // Nunca deixa o título genérico da Shopee ("Shopee Brasil | Ofertas
        // incríveis...", que aparece antes da SPA hidratar) virar o nome
        // salvo do link — nesse caso usa um fallback decente em vez disso.
        const isGenericTitle = (t) => !t || /ofertas incr[ií]veis/i.test(t);
        const bestTitle = [message.title, pending.title].find((t) => !isGenericTitle(t));

        payload = {
          productId: message.productId || (message.itemId ? `shopee-${message.itemId}` : undefined),
          title: bestTitle || "Produto Shopee",
          url: message.url,
          marketplace: "shopee",
          image: message.image || pending.image,
          productUrl: pending.productUrl,
        };
      }

      if (pending.originTabId) {
        // Devolve o foco pra aba do produto na Shopee, já que a aba de
        // automação precisou ficar em primeiro plano por causa do throttling.
        chrome.tabs.update(pending.originTabId, { active: true }).catch(() => {});
        if (pending.originWindowId) {
          chrome.windows.update(pending.originWindowId, { focused: true }).catch(() => {});
        }

        chrome.tabs
          .sendMessage(pending.originTabId, {
            type: "AFFILIATE_DONE",
            requestId: message.requestId,
            ok: message.ok,
            url: message.url,
            error: message.error,
            debug: message.debug,
            payloadDebug: payload,
            rawMessageTitle: message.title,
            rawMessageImage: message.image,
            rawPendingTitle: pending.title,
            rawPendingImage: pending.image,
          })
          .catch(() => {});
      }

      if (message.ok) {
        const fornecefyTabs = await chrome.tabs.query({ url: APP_URL_PATTERNS });

        let delivered = false;
        for (const t of fornecefyTabs) {
          try {
            await chrome.tabs.sendMessage(t.id, { type: "SAVE_LINK", payload });
            delivered = true;
          } catch {
            // essa aba não tem o content script pronto (não é o Shopfy de
            // fato, só bateu num dos host_permissions acima) — ignora
          }
        }

        if (!delivered) {
          await queueUnsynced(payload);
        }

        await notify(
          "Shopfy",
          delivered
            ? `Link salvo automaticamente: ${pending.title}`
            : `Link gerado! Abra o Shopfy pra salvar: ${pending.title}`,
        );
      } else {
        await notify(
          "Shopfy",
          `Não consegui gerar o link de "${pending.title}" — tente manualmente na Shopee.`,
        );
      }

      await clearPending(message.requestId);
    })();
    return false;
  }

  if (message.type === "FORNECEFY_TAB_READY") {
    if (sender.tab) {
      flushQueueToTab(sender.tab.id);
    }
    return false;
  }

  return false;
});
