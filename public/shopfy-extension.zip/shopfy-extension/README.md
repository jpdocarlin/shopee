# Shopfy — Virar Afiliado Automático

Extensão de Chrome que, ao clicar em "Virar afiliado" numa página de produto da
Shopee, busca esse produto sozinha no Portal de Afiliados, pega o link e salva
direto na página **Meus Links** do Shopfy — sem precisar copiar e colar nada.

Durante a busca, uma aba do Portal de Afiliados abre por alguns segundos (o
Chrome trava os timers de abas em segundo plano, então ela precisa ficar em
primeiro plano pra funcionar) e fecha sozinha, voltando pra sua aba original.

Como não está publicada na Chrome Web Store (isso exigiria revisão da Google),
ela precisa ser carregada manualmente uma vez, como extensão "descompactada".
Uma vez carregada, fica instalada normalmente até você remover.

## Como instalar

1. Abra `chrome://extensions` no Chrome.
2. Ative o **Modo do desenvolvedor** (canto superior direito).
3. Clique em **Carregar sem compactação** (Load unpacked).
4. Selecione esta pasta (`fornecefy-extension`).
5. Pronto — o ícone do Shopfy aparece na barra de extensões.

## Como usar

1. Deixe o Shopfy aberto numa aba (`npm run dev` ou o `iniciar-fornecefy.command`).
2. Entre em qualquer produto da Shopee (`shopee.com.br/.../produto-i.123.456`).
3. Vai aparecer um botão flutuante laranja no canto inferior direito:
   **"Virar afiliado (Shopfy)"**.
4. Clique. A extensão abre uma aba escondida no portal de afiliados, busca o
   produto pelo nome, clica em "Obter link", pega o link gerado e fecha a aba
   sozinha — tudo em alguns segundos.
5. O link aparece automaticamente em **Meus Links** no Shopfy. Se o
   Shopfy não estiver aberto no momento, o link fica guardado e é entregue
   assim que você abrir uma aba dele.

## Limitações e coisas pra saber

- **Você precisa estar logado no Portal de Afiliados da Shopee** no mesmo
  navegador — a extensão não faz login por você.
- A extensão **casa o produto pelo nome** (comparação por texto, não é 100%
  garantido) — em produtos com nome muito genérico ou muito diferente do
  título da página, pode não achar. Nesse caso o botão mostra erro e você
  ainda pode virar afiliado manualmente pela página "Produtos" do Shopfy.
- Se a Shopee mudar o layout do Portal de Afiliados, a automação pode parar
  de funcionar até alguém atualizar os seletores em
  `content-scripts/shopee-affiliate.js`.
- Não publicamos isso na Chrome Web Store — é uma extensão "caseira", local,
  só pra você. Se quiser usar em outro computador, copie esta pasta.
- A extensão só conversa com `shopee.com.br`, `affiliate.shopee.com.br` e
  páginas em `localhost`/`127.0.0.1` (onde o Shopfy roda). Ela não lê nem
  manda dados pra nenhum outro lugar.

## Estrutura

```
manifest.json                        Configuração da extensão (Manifest V3)
background.js                        Orquestra o fluxo (abre aba, junta as pontas)
content-scripts/shopee-product.js    Botão flutuante na página do produto
content-scripts/shopee-affiliate.js  Busca + clica "Obter link" no portal
content-scripts/fornecefy-bridge.js  Entrega o link pro app React do Shopfy
popup.html / popup.js                Popup do ícone da extensão
icons/                               Ícones da extensão
```
