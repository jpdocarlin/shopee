// Roda em toda página da Shopee (menos o portal de afiliados). Se a URL for
// de um produto, injeta um botão flutuante "Virar afiliado (Shopfy)" que
// dispara o fluxo automático no background.js.
(function () {
  // A Shopee usa mais de um formato de URL pra página de produto:
  //   /<slug>-i.<shopid>.<itemid>      (navegação normal pelo site)
  //   /product/<shopid>/<itemid>       (links de afiliado / redirecionados)
  const PRODUCT_URL_PATTERNS = [/-i\.\d+\.\d+(?:[/?#]|$)/, /\/product\/\d+\/\d+(?:[/?#]|$)/];
  const ITEM_ID_PATTERNS = [/-i\.\d+\.(\d+)(?:[/?#]|$)/, /\/product\/\d+\/(\d+)(?:[/?#]|$)/];

  function isProductPage() {
    const path = location.pathname + location.search;
    return PRODUCT_URL_PATTERNS.some((re) => re.test(path));
  }

  // O itemId dá acesso direto à página de oferta desse produto específico no
  // portal de afiliados (affiliate.shopee.com.br/offer/product_offer/<id>) —
  // sem precisar buscar por nome, então não depende do título da página ter
  // carregado. Ele já vem pronto na URL, ao contrário do título (que demora).
  function getItemId() {
    const path = location.pathname;
    for (const re of ITEM_ID_PATTERNS) {
      const match = path.match(re);
      if (match) return match[1];
    }
    return null;
  }

  // O título da página (og:title/document.title) demora vários segundos pra
  // trocar do texto genérico da Shopee pelo nome real do produto — depender
  // dele pra achar o produto no portal de afiliados é frágil (a busca por
  // texto falhava direto). Agora que temos o itemId (instantâneo, direto da
  // URL), o título só serve como legenda bonita pro link salvo — não é mais
  // crítico, então não bloqueamos o clique esperando ele.
  function getProductTitle() {
    // Tanto og:title quanto document.title costumam vir com um sufixo tipo
    // " | Shopee Brasil" — tira esse sufixo dos dois.
    const og = document.querySelector('meta[property="og:title"]');
    const raw = (og && og.content) || document.title;
    return raw.replace(/\s*\|\s*Shopee.*$/i, "").trim();
  }

  function getProductImage() {
    const og = document.querySelector('meta[property="og:image"]');
    return og && og.content ? og.content.trim() : undefined;
  }

  function mountButton() {
    if (document.getElementById("fornecefy-widget-host")) return;

    const host = document.createElement("div");
    host.id = "fornecefy-widget-host";
    host.style.position = "fixed";
    host.style.bottom = "20px";
    host.style.right = "20px";
    host.style.zIndex = "2147483647";
    document.body.appendChild(host);

    const shadow = host.attachShadow({ mode: "open" });
    shadow.innerHTML = `
      <style>
        .btn {
          all: initial;
          font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", sans-serif;
          display: inline-flex;
          align-items: center;
          gap: 8px;
          background: #EE4D2D;
          color: #fff;
          padding: 12px 18px;
          border-radius: 999px;
          font-size: 13px;
          font-weight: 600;
          cursor: pointer;
          box-shadow: 0 8px 24px rgba(0,0,0,0.25);
          transition: transform 0.15s ease, background 0.15s ease;
          user-select: none;
        }
        .btn:hover { transform: translateY(-1px); }
        .btn.loading { background: #9c9c9c; cursor: default; }
        .btn.success { background: #16a34a; }
        .btn.error { background: #dc2626; }
        .dot {
          width: 8px;
          height: 8px;
          border-radius: 50%;
          background: #fff;
          opacity: 0.9;
        }
      </style>
      <div class="btn" id="fornecefy-btn">
        <span class="dot"></span>
        <span id="fornecefy-btn-label">Virar afiliado (Shopfy)</span>
      </div>
    `;

    const btn = shadow.getElementById("fornecefy-btn");
    const label = shadow.getElementById("fornecefy-btn-label");
    let currentRequestId = null;
    let timeoutHandle = null;

    function setState(state, text) {
      btn.classList.remove("loading", "success", "error");
      if (state) btn.classList.add(state);
      label.textContent = text;
    }

    btn.addEventListener("click", () => {
      if (btn.classList.contains("loading")) return;

      setState("loading", "Gerando link...");

      const title = getProductTitle();
      const image = getProductImage();
      const itemId = getItemId();
      host.dataset.fornecefyLastRequest = JSON.stringify({ title, productUrl: location.href, image, itemId });

      chrome.runtime.sendMessage(
        {
          type: "AFFILIATE_REQUEST",
          title,
          productUrl: location.href,
          image,
          itemId,
        },
        (response) => {
          if (chrome.runtime.lastError || !response) {
            setState("error", "Erro — tenta de novo");
            window.setTimeout(() => setState("", "Virar afiliado (Shopfy)"), 3000);
            return;
          }
          currentRequestId = response.requestId;

          // O portal de afiliados pode demorar bastante pra gerar um link novo
          // (medido ao vivo: até ~16s só nessa etapa) — esse timeout do botão
          // precisa ser maior que o do background.js (45s) pra não desistir
          // antes da resposta real chegar.
          timeoutHandle = window.setTimeout(() => {
            setState("error", "Demorou demais — tenta de novo");
            window.setTimeout(() => setState("", "Virar afiliado (Shopfy)"), 3000);
          }, 50000);
        },
      );
    });

    chrome.runtime.onMessage.addListener((message) => {
      if (message.type !== "AFFILIATE_DONE") return;
      // DEBUG temporário: console.log de content script não aparece em toda
      // ferramenta de inspeção, então gravamos o diagnóstico direto num
      // atributo do DOM (dataset), que dá pra ler de fora com JS comum.
      host.dataset.fornecefyLast = JSON.stringify({ at: Date.now(), message, currentRequestId });
      if (message.requestId !== currentRequestId) return;

      if (timeoutHandle) window.clearTimeout(timeoutHandle);

      if (message.ok) {
        setState("success", "Salvo no Shopfy ✓");
        window.setTimeout(() => setState("", "Virar afiliado (Shopfy)"), 4000);
      } else {
        setState("error", "Erro: " + (message.error || "desconhecido"));
        window.setTimeout(() => setState("", "Virar afiliado (Shopfy)"), 8000);
      }
    });
  }

  function init() {
    if (isProductPage()) {
      mountButton();
    }
  }

  init();

  // Shopee é uma SPA — a URL muda sem recarregar a página inteira.
  let lastPath = location.href;
  new MutationObserver(() => {
    if (location.href !== lastPath) {
      lastPath = location.href;
      const existing = document.getElementById("fornecefy-widget-host");
      if (isProductPage()) {
        if (!existing) mountButton();
      } else if (existing) {
        existing.remove();
      }
    }
  }).observe(document.body, { childList: true, subtree: true });
})();
