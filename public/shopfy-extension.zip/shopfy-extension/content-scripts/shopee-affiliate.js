// Roda dentro do Portal de Afiliados da Shopee (aba escondida, aberta pelo
// background.js). Lê o pedido pendente pelo hash da URL, clica em "Obter
// link" no produto certo, lê o link gerado e devolve o resultado pro
// background — que entrega pro Fornecefy.
//
// Dois modos:
//  - DIRETO (preferido): quando temos o itemId do produto, o background já
//    abre direto em affiliate.shopee.com.br/offer/product_offer/<itemId> —
//    uma página que mostra só ESSE produto com um único botão "Obter link".
//    Não precisa buscar nada, não depende de título de página nenhuma.
//  - BUSCA (fallback): usado só se por algum motivo não tivermos o itemId.
//    Busca por nome no campo de busca geral e tenta casar o card certo.
(function () {
  const hashMatch = location.hash.match(/fornecefy_req=([\w-]+)/);
  if (!hashMatch) return; // aba normal do portal, não veio da extensão

  const requestId = hashMatch[1];
  // O portal pode demorar bastante pra gerar um link novo (medido ao vivo:
  // até ~16s só nessa etapa) — o timeout geral precisa sobrar espaço pra
  // isso além do tempo de carregar a página e achar o botão.
  const SELF_TIMEOUT_MS = 45000;
  let finished = false;
  let currentStep = "start";

  function finish(result) {
    if (finished) return;
    finished = true;
    chrome.runtime.sendMessage({ type: "AFFILIATE_RESULT", requestId, ...result });
  }

  const selfTimeout = window.setTimeout(() => {
    finish({ ok: false, error: "timeout", debug: { step: currentStep } });
  }, SELF_TIMEOUT_MS);

  function waitFor(check, { timeout = 10000, interval = 250 } = {}) {
    return new Promise((resolve, reject) => {
      const start = Date.now();
      const tick = () => {
        const value = check();
        if (value) {
          resolve(value);
          return;
        }
        if (Date.now() - start > timeout) {
          reject(new Error("timeout"));
          return;
        }
        window.setTimeout(tick, interval);
      };
      tick();
    });
  }

  // Marcas de acento Unicode combinantes (ex: á = a + este marcador), pra
  // tirar acento depois de normalize("NFD"). Construído a partir dos pontos
  // de código (0x0300–0x036f) em vez de caracteres literais, pra evitar
  // qualquer ambiguidade de encoding no arquivo.
  const DIACRITICS_RE = new RegExp("[\\u0300-\\u036f]", "g");

  function normalize(text) {
    return (text || "")
      .normalize("NFD")
      .replace(DIACRITICS_RE, "")
      .toLowerCase()
      .replace(/[^a-z0-9\s]/g, " ")
      .replace(/\s+/g, " ")
      .trim();
  }

  function similarity(a, b) {
    const na = normalize(a);
    const nb = normalize(b);
    if (!na || !nb) return 0;
    if (na === nb) return 1;
    const wordsA = new Set(na.split(" "));
    const wordsB = new Set(nb.split(" "));
    let overlap = 0;
    for (const w of wordsA) if (wordsB.has(w)) overlap++;
    return overlap / Math.min(wordsA.size, wordsB.size || 1);
  }

  function setNativeValue(input, value) {
    const setter = Object.getOwnPropertyDescriptor(
      window.HTMLInputElement.prototype,
      "value",
    ).set;
    setter.call(input, value);
    input.dispatchEvent(new Event("input", { bubbles: true }));
  }

  function findButtonByText(root, text) {
    const buttons = root.querySelectorAll("button");
    for (const btn of buttons) {
      if (btn.textContent && btn.textContent.trim() === text) return btn;
    }
    return null;
  }

  // Igual findButtonByText, mas por substring case-insensitive — usado pro
  // botão "Copiar Link" dentro do modal, cujo texto exato já mudou pelo menos
  // uma vez (ver findFilledLinkField abaixo) e pode variar de novo.
  function findButtonByTextIncludes(root, ...needles) {
    const buttons = root.querySelectorAll("button");
    for (const btn of buttons) {
      const text = (btn.textContent || "").trim().toLowerCase();
      if (needles.some((n) => text.includes(n))) return btn;
    }
    return null;
  }

  function findFilledLinkField() {
    const fields = Array.from(document.querySelectorAll("textarea, input"));
    return fields.find((f) => /^https?:\/\//.test((f.value || "").trim())) || null;
  }

  async function extractLinkFromModal() {
    // Historicamente o campo do modal já vinha preenchido sozinho, então essa
    // função só esperava. Em 05/08/2026 constatamos ao vivo (relato do Jp, com
    // print) que o portal mudou: o modal abre com o campo "Por favor, copie o
    // link" vazio, exigindo clicar em "Copiar Link" pra Shopee de fato gerar
    // e popular o valor. Tenta o caminho rápido (campo já preenchido) primeiro
    // — caso a Shopee volte a mudar pra esse comportamento — e só clica em
    // "Copiar Link" se, depois de uma espera curta, o campo continuar vazio.
    const already = await waitFor(findFilledLinkField, { timeout: 2000 }).catch(() => null);
    if (already) return already;

    const copyBtn = findButtonByTextIncludes(
      document,
      "copiar link",
      "copiar o link",
      "copy link",
    );
    if (copyBtn) copyBtn.click();

    // Timeout generoso pra não desistir antes da hora — o portal gera o link
    // sob demanda (chamada de API própria dele) e, medido ao vivo, pode levar
    // bem mais que alguns segundos pra popular o campo depois do clique.
    try {
      return await waitFor(findFilledLinkField, { timeout: 30000 });
    } catch (err) {
      // Debug melhor que um "timeout" seco: se nem achamos o botão "Copiar
      // Link" pra clicar, é bem provável que a Shopee tenha mudado o texto ou
      // a estrutura do modal de novo — vale saber isso na hora de investigar.
      err.message = copyBtn
        ? "timeout-apos-clicar-copiar-link"
        : "timeout-sem-achar-botao-copiar-link";
      throw err;
    }
  }

  function isModalOpen() {
    return !!document.querySelector(".ant-modal, .ant-modal-body");
  }

  async function runDirect(pending) {
    currentStep = "wait-obter-link-direto";
    const obterLinkBtn = await waitFor(() => findButtonByText(document, "Obter link"), {
      timeout: 12000,
    });

    // Nome/imagem do produto direto dessa página (carrega rápido e não
    // depende da SPA da Shopee hidratar, ao contrário da página de origem).
    // O botão "Obter link" pode renderizar antes do nome/preço (chamada de
    // API separada, às vezes mais lenta) — por isso essa extração roda de
    // novo depois do clique também (tempo de sobra já que a extração do link
    // no modal pode levar até 30s de qualquer forma).
    function extractNameImage() {
      const viewProductLink = document.querySelector("a.view-product");
      const nameEl =
        (viewProductLink && viewProductLink.parentElement.querySelector(".name")) ||
        document.querySelector(".name-wrap .name");
      const rawTitle = nameEl ? nameEl.textContent.trim() : "";
      // Nunca manda um título vazio/curto demais (ex: "-") — nesse caso deixa
      // undefined pra o background.js usar o título capturado na página de
      // origem como respaldo, em vez de salvar um link sem nome de verdade.
      const title = rawTitle.length > 1 ? rawTitle : undefined;
      const imgEl = document.querySelector('img[src*="susercontent"]');
      const image = imgEl ? imgEl.src : undefined;
      return { title, image };
    }

    currentStep = "extrair-nome-imagem";
    await waitFor(() => document.querySelector("a.view-product .name, .name-wrap .name"), {
      timeout: 15000,
    }).catch(() => null);
    let { title, image } = extractNameImage();

    // O botão pode existir no DOM antes do React terminar de "hidratar" e
    // ligar o onClick de verdade — um clique nesse meio-tempo não faz nada.
    // Dá uma folga curta antes do primeiro clique, e se o modal não abrir,
    // tenta de novo (até 3x) antes de desistir.
    await new Promise((r) => window.setTimeout(r, 600));

    currentStep = "clicar-obter-link";
    let modalOpened = false;
    for (let attempt = 0; attempt < 3 && !modalOpened; attempt++) {
      obterLinkBtn.click();
      try {
        await waitFor(() => isModalOpen(), { timeout: 2500, interval: 200 });
        modalOpened = true;
      } catch {
        // não abriu — tenta de novo
      }
    }
    if (!modalOpened) {
      throw new Error("modal-nao-abriu-apos-clique");
    }

    currentStep = "esperar-campo-link";
    const linkField = await extractLinkFromModal();

    // Se não achou nome/imagem antes (API mais lenta que o normal), tenta de
    // novo agora — nesse ponto o link já foi gerado, então a página com
    // certeza terminou de carregar os dados do produto.
    if (!title || !image) {
      const retry = extractNameImage();
      title = title || retry.title;
      image = image || retry.image;
    }

    const url = linkField.value.trim();
    window.clearTimeout(selfTimeout);
    finish({ ok: true, url, productId: `shopee-${pending.itemId}`, title, image });
  }

  async function runSearch(pending) {
    currentStep = "wait-search-input";
    const searchInput = await waitFor(
      () => document.querySelector('input[placeholder*="Buscar por todos os produtos"]'),
      { timeout: 12000 },
    );

    currentStep = "type-search";
    setNativeValue(searchInput, pending.title);

    // O botão "Pesquisar" do portal é um <div> dentro de um Input.Search do
    // Ant Design, não um <button> de verdade — simula a tecla Enter.
    searchInput.dispatchEvent(
      new KeyboardEvent("keydown", { key: "Enter", code: "Enter", keyCode: 13, which: 13, bubbles: true }),
    );
    searchInput.dispatchEvent(
      new KeyboardEvent("keyup", { key: "Enter", code: "Enter", keyCode: 13, which: 13, bubbles: true }),
    );

    await new Promise((r) => window.setTimeout(r, 2500));

    currentStep = "wait-cards";
    const cards = await waitFor(
      () => {
        const found = Array.from(document.querySelectorAll('a[href*="/offer/product_offer/"]'));
        return found.length > 0 ? found : null;
      },
      { timeout: 10000 },
    );

    currentStep = "match-product";
    let best = null;
    let bestScore = 0;
    const scored = [];
    for (const card of cards) {
      const nameEl = card.querySelector(".ItemCard__name") || card;
      const score = similarity(nameEl.textContent, pending.title);
      scored.push({ name: (nameEl.textContent || "").trim().slice(0, 60), score: Math.round(score * 100) / 100 });
      if (score > bestScore) {
        bestScore = score;
        best = card;
      }
    }

    if (!best || bestScore < 0.3) {
      scored.sort((a, b) => b.score - a.score);
      finish({
        ok: false,
        error: "product-not-found",
        debug: { searchedTitle: pending.title, cardsFound: cards.length, topCandidates: scored.slice(0, 5) },
      });
      return;
    }

    const idMatch = best.href.match(/product_offer\/(\d+)/);
    const productId = idMatch ? `shopee-${idMatch[1]}` : undefined;

    currentStep = "click-obter-link";
    const obterLinkBtn = findButtonByText(best, "Obter link");
    if (!obterLinkBtn) {
      finish({ ok: false, error: "no-obter-link-button", debug: { step: currentStep, searchedTitle: pending.title } });
      return;
    }
    obterLinkBtn.click();

    currentStep = "wait-link-field";
    const linkField = await extractLinkFromModal();

    const url = linkField.value.trim();
    window.clearTimeout(selfTimeout);
    finish({ ok: true, url, productId });
  }

  async function run() {
    const data = await chrome.storage.local.get("pending_" + requestId);
    const pending = data["pending_" + requestId];
    if (!pending) {
      finish({ ok: false, error: "no-pending-data" });
      return;
    }

    try {
      if (pending.itemId) {
        await runDirect(pending);
      } else {
        await runSearch(pending);
      }
    } catch (err) {
      finish({
        ok: false,
        error: "automation-failed",
        debug: { step: currentStep, searchedTitle: pending.title, message: err && err.message },
      });
    }
  }

  run();
})();
