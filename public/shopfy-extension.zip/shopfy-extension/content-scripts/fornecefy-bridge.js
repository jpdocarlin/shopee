// Roda em qualquer página localhost/127.0.0.1 (onde o Fornecefy costuma
// rodar em dev). Faz a ponte entre o background.js (mundo da extensão) e o
// app React (mundo da página) via window.postMessage — o app só confia em
// mensagens vindas da própria window, nunca direto da extensão.
(function () {
  // window.postMessage não garante entrega: se o app React ainda não montou
  // o listener (useExtensionBridge) no exato momento em que a extensão manda
  // o link, a mensagem se perde pra sempre — sem erro, sem fila, o link some.
  // Isso é bem provável de acontecer logo depois de um F5, já que
  // document_idle costuma disparar antes do app terminar de hidratar. Pra
  // resolver, espera confirmação (ACK) da página e reenvia com backoff até
  // confirmar ou desistir.
  let ackedKeys = new Set();

  window.addEventListener("message", (event) => {
    if (event.source !== window) return;
    const data = event.data;
    if (!data || data.source !== "fornecefy-app" || data.type !== "SAVE_LINK_ACK") return;
    if (data.productId) ackedKeys.add(data.productId);
    if (data.url) ackedKeys.add(data.url);
  });

  function postWithRetry(payload, attempt = 0) {
    const key = payload.productId || payload.url;
    window.postMessage({ source: "fornecefy-extension", type: "SAVE_LINK", payload }, "*");

    if (attempt >= 6) return; // ~ (500+800+1200+1800+2700+4000)ms de tentativas
    const delay = 500 * Math.pow(1.5, attempt);
    window.setTimeout(() => {
      if (ackedKeys.has(key) || ackedKeys.has(payload.url)) return; // app já confirmou
      postWithRetry(payload, attempt + 1);
    }, delay);
  }

  chrome.runtime.onMessage.addListener((message) => {
    if (!message || message.type !== "SAVE_LINK") return;
    postWithRetry(message.payload);
  });

  // Avisa o background que esta aba do Fornecefy está pronta — se tiver
  // algum link gerado enquanto nenhuma aba do Fornecefy estava aberta, ele
  // entrega agora. Um pequeno atraso dá tempo do app React montar antes da
  // primeira tentativa (o retry acima cobre o resto).
  window.setTimeout(() => {
    chrome.runtime.sendMessage({ type: "FORNECEFY_TAB_READY" });
  }, 800);
})();
