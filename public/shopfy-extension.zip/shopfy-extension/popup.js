// Mesmas origens que o background.js reconhece como "o Shopfy" — produção
// (domínio próprio e alias da Vercel) e o ambiente local de dev.
const APP_URL_PATTERNS = [
  "https://shoppfy.online/*",
  "https://www.shoppfy.online/*",
  "https://shoppfy-five.vercel.app/*",
  "http://localhost/*",
  "http://127.0.0.1/*",
];

document.getElementById("open-fornecefy").addEventListener("click", async () => {
  const tabs = await chrome.tabs.query({ url: APP_URL_PATTERNS });

  if (tabs.length > 0) {
    const tab = tabs[0];
    const base = new URL(tab.url);
    await chrome.tabs.update(tab.id, { active: true, url: `${base.origin}/meus-links` });
    await chrome.windows.update(tab.windowId, { focused: true });
  } else {
    // Nenhuma aba do Shopfy aberta — abre direto a versão em produção.
    await chrome.tabs.create({ url: "https://shoppfy.online/meus-links" });
  }

  window.close();
});
