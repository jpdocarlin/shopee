document.getElementById("open-fornecefy").addEventListener("click", async () => {
  const tabs = await chrome.tabs.query({ url: ["http://localhost/*", "http://127.0.0.1/*"] });

  if (tabs.length > 0) {
    const tab = tabs[0];
    const base = new URL(tab.url);
    await chrome.tabs.update(tab.id, { active: true, url: `${base.origin}/meus-links` });
    await chrome.windows.update(tab.windowId, { focused: true });
  } else {
    // porta padrão do Fornecefy local — se estiver em outra porta, o botão
    // flutuante na Shopee já vai encontrar a aba certa quando ela existir
    await chrome.tabs.create({ url: "http://localhost:8081/meus-links" });
  }

  window.close();
});
